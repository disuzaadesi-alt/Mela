# MELA Backend — Setup Guide (step by step)

Yeh real backend hai: PostgreSQL database, password-based login, aur Razorpay
test-mode payments. In steps ko order mein follow karo.

## Step 1 — Free PostgreSQL database banao

1. https://neon.tech pe jao, free account banao (sirf email chahiye).
2. New project banao → "Connection string" copy karo.
3. `.env.example` ko `.env` naam se copy karo, aur `DATABASE_URL` mein wahi
   connection string paste karo.

## Step 2 — Local machine par install

```bash
cd mela-backend
npm install
```

## Step 3 — JWT secret set karo

`.env` file mein `JWT_SECRET` ko koi bhi lamba random string bana do
(jaise: `openssl rand -hex 32` terminal mein chala ke).

## Step 4 — Database tables banao

```bash
npx prisma migrate dev --name init
```

Yeh command tumhare Postgres database mein User, Product, Order, OrderItem
tables bana degi.

## Step 5 — Demo products database mein daalo

```bash
npm run seed
```

## Step 6 — Razorpay test keys lo (payment ke liye)

1. https://dashboard.razorpay.com/signup pe free account banao — koi
   business document abhi nahi chahiye, test mode automatically on hota hai.
2. Dashboard → Settings → API Keys → "Generate Test Key" click karo.
3. `Key Id` aur `Key Secret` ko `.env` mein `RAZORPAY_KEY_ID` aur
   `RAZORPAY_KEY_SECRET` mein daalo.
4. Test mode mein real paisa nahi katega — Razorpay test card number hota
   hai `4111 1111 1111 1111` (koi bhi future date, koi bhi CVV).

Jab tak Razorpay se real payment lena hai (asli paisa apne account mein),
tab tumhe apna business KYC — PAN card, bank account — Razorpay ko
submit karke activate karwana padega. Woh sirf tumhare through ho sakta hai.

## Step 7 — Server chalao

```bash
npm run dev
```

Server `http://localhost:4000` par chalega. Test karo:
```bash
curl http://localhost:4000
```

## Step 8 — Deploy karo (taki koi bhi internet se access kar sake)

1. Code ko GitHub par push karo.
2. https://render.com ya https://railway.app pe free account banao.
3. "New Web Service" → apna GitHub repo connect karo.
4. Environment variables (.env wali sab cheezein) waha ke dashboard mein
   paste karo.
5. Deploy hone ke baad tumhe ek public URL milega jaise
   `https://mela-backend.onrender.com` — yehi URL frontend mein use hoga.

## API endpoints (frontend inhe call karega)

| Method | Endpoint                  | Auth       | Kaam                          |
|--------|----------------------------|------------|-------------------------------|
| POST   | /api/auth/signup           | —          | New account banao             |
| POST   | /api/auth/login            | —          | Login, token milta hai        |
| GET    | /api/products               | —          | Sab products dekho            |
| POST   | /api/products               | Admin      | Naya product add karo         |
| PUT    | /api/products/:id           | Admin      | Product edit karo             |
| DELETE | /api/products/:id           | Admin      | Product delete karo           |
| POST   | /api/orders                 | Login      | Order place karo              |
| GET    | /api/orders                 | Login      | Apne orders dekho             |
| GET    | /api/orders/all              | Admin      | Sab customers ke orders       |
| PATCH  | /api/orders/:id/stage        | Admin      | Order ka status aage badhao   |
| POST   | /api/payment/verify          | Login      | Payment confirm karo          |

Agla step: frontend (MELA site) ko is backend se connect karna — woh
main agle message mein karunga.
